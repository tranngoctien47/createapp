


export const List = [
    {
        title: 'Total Transaction',
        value: '3873'
    },
    {
        title: 'Total Vollume',
        value: '3873'
    },
    {
        title: 'Total NFT items',
        value: '12'
    },


]
