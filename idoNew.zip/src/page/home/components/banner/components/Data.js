import Spring from "asset/svg/spring.svg";
import Summer from "asset/svg/summer.svg";
import Winter from "asset/svg/winter.svg";
import Autumn from "asset/svg/autumn.svg";

export const listImg = [{
        img: Spring,
    },
    {
        img: Summer,
    },
    {
        img: Winter,
    },
    {
        img: Autumn,
    },
];