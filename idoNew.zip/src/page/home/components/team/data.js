import Avatar from "asset/svg/avatar1.svg";
import Avatar2 from "asset/svg/avatar2.svg";
import Avatar3 from "asset/svg/avatar3.svg";
import Avatar4 from "asset/svg/avatar4.svg";
import Avatar5 from "asset/svg/avatar5.svg";



export const ListTeam = [{
    title: "Warran",
    des: "CO-FOUNDER",
    avarat: Avatar,
},
{
    title: "Roman",
    des: "CEO",
    avarat: Avatar2,
},
{
    title: "Mary",
    des: "ARTISTER",
    avarat: Avatar3,
},
{
    title: "Kate",
    des: "PR & MARKETING",
    avarat: Avatar4,
},
{
    title: "Charles",
    des: "PM",
    avarat: Avatar5,
},
];