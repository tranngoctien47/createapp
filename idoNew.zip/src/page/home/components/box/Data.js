

export const listBox = [
    {
        des: "x100 species",
        bg: 'linear-gradient(90deg, rgba(0, 194, 242, 0) 1.1%, #0576F6 51.22%, rgba(3, 68, 255, 0) 96.37%);',
    },
    {
        des: "x1 NFT plot",
        bg: 'none',
    },
    {
        des: "x1 NFT beast cages",
        bg: 'linear-gradient(90deg, rgba(0, 194, 242, 0) 1.1%, #0576F6 51.22%, rgba(3, 68, 255, 0) 96.37%);',
    },
    {
        des: "x5 - x10 nutrition boxes",
        bg: 'none',
    },
    {
        des: "x5 - x10 P2P battle cards",
        bg: 'linear-gradient(90deg, rgba(0, 194, 242, 0) 1.1%, #0576F6 51.22%, rgba(3, 68, 255, 0) 96.37%);',
    },
    {
        des: "x1 NFT beast ( random 1* - 5*)",
        bg: 'none',
    },


];