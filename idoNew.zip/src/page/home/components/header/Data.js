export const listHeader = [
    {
        title: "HOME ",

    },
    {
        title: "ABOUT ",
    },
    {
        title: "NFT ITEMS",
    },
    {
        title: "TOKENOMICS",
    },
    {
        title: "ROADMAP",
    },
    {
        title: "TEAM",
    },

];

