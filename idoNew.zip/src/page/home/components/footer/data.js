import tele from 'asset/svg/mxh1.svg'
import tw from 'asset/svg/mxh2.svg'
import you from 'asset/svg/mxh3.svg'
import fb from 'asset/svg/mxh4.svg'
import ins from 'asset/svg/mxh5.svg'
import dis from 'asset/svg/mxh6.svg'


export const ListAboutUs = [
    {
        text: 'About',
    },
    {
        text: 'Tems',
    },
    {
        text: 'Privacy',
    },
    {
        text: 'Contact us',
    },

]
export const ListMxh = [
    {
        img: tele,
    },
    {
        img: tw,
    },
    {
        img: you,
    },
    {
        img: fb,
    },
    {
        img: ins,
    },
    {
        img: dis,
    },

]